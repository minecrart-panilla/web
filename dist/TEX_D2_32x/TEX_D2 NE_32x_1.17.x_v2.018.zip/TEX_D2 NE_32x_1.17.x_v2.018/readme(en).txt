Thank you for downloading TEX-D2-NE!

First of all, I would like to say that this resource pack
First of all, I would like to state that this resource pack is created and distributed with the permission of daigoman, the author of the original TEX-D TEX-D2.
This resource pack has been created and distributed with the permission of daigoman, the author of the original TEX-D TEX-D2, and in accordance with the included TEX-D2 Secondary Distribution Guidelines.

The terms of use are in line with the original TEX-D2 resource pack, as follows

---------------------------------------------------------------------------------------------------------------------------

Individuals and companies are free to use the textures in their videos, screenshots, and live broadcasts.
Please feel free to do so. There is no need to contact us if you want to use them in commercial media.


---------------------------------------------------------------------------------------------------------------------------
Secondary distribution (redistribution) of this resource pack is prohibited.

Translated with www.DeepL.com/Translator (free version)